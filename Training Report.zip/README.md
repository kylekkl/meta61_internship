# Industrial Training Report Template
Template for Industrial Training Report in University of Nottingham.

## Requirements

Engine: XeLaTeX

### Packages

- fontspec
- geometry
- setspace
- graphicx
- biblatex
